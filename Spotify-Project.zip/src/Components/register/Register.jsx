import React, { useState } from 'react';
import {useNavigate} from 'react-router-dom';
//import { fetchSpotifyApi } from './API/spotifyAPI';
import { authFLow, getDataAuth } from '../../setup'; 
//import "../setup"; 

const Register = () => {
    const [form, setForm] = useState({
        email: '',
        password: ''
    });

    const navigate = useNavigate();

    const handleOnChange = (e) => {
        const newValues = {
          ...form,
          [e.target.name]: e.target.value,
        };
        setForm(newValues);
      };


    const handleLogin = async (e) => {
        e.preventDefault();
    
        const codeChallengeProm = await getDataAuth();
        authFLow(codeChallengeProm);
    }

    // const handleLogin = async () => {
    //     navigate('/dashboard');
    //     const client_id='0b240077cb6f476bba568d3d3b77db33';
    //     const client_secret='e1e304b683394139aadef0bb4006d408';
    //     const url='https://accounts.spotify.com/api/token';
    //     const body= 'grant_type=client_credentials';
    //     const token= "Basic " + btoa(client_id + ':' + client_secret);
    //     const response= await fetchSpotifyApi(url, 'POST', body, 'application/x-www-form-urlencoded', token); 
        
    //     localStorage.setItem('token', response.access_token);
    //     console.log(response); 
        
    // };

    return (
        <div className="register-container" style={{ backgroundColor: '#000', color: '#fff', height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
    <form className="register-form" style={{ display: 'flex', flexDirection: 'column', width: '300px', padding: '20px', borderRadius: '5px', backgroundColor: '#282828' }}>
        <h2 style={{ textAlign: 'center', color: '#1DB954' }}>Spotify</h2>
        <label style={{ marginBottom: '5px' }}>Email address</label>
        <input
            type="email"
            name="email"
            placeholder="Email"
            value={form.email}
            onChange={handleOnChange}
            style={{ marginBottom: '20px', padding: '10px', borderRadius: '5px' }}
        />
        <label style={{ marginBottom: '5px' }}>Password</label>
        <input
            type="password"
            name="password"
            placeholder="Password"
            value={form.password}
            onChange={handleOnChange}
            autoComplete="current-password"
            style={{ marginBottom: '20px', padding: '10px', borderRadius: '5px' }}
        />
        <button type="submit" onClick={handleLogin} style={{ padding: '10px', borderRadius: '30px', backgroundColor: '#1DB954', color: '#fff', border: 'none', cursor: 'pointer' }}>
         Register
        </button>
    </form>
</div>
      );
    };   


export default Register; 